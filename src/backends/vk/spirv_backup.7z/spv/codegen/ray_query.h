#pragma once
#include "types.h"
namespace toolhub::spv {
class RayQuery {
	RayQuery() = delete;

public:
	static void PrintFunc(Builder* bd);
};
}// namespace toolhub::spv
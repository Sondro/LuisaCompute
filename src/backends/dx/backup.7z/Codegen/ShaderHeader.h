#pragma once
#include <vstl/Common.h>
namespace toolhub::directx {
vstd::string_view GetAccelProcessCompute();
vstd::string_view GetHeader();
vstd::string_view GetRayTracingHeader();
vstd::string_view BC6Include();
vstd::string_view BC6TryModeG10CS();
vstd::string_view BC6TryModeLE10CS();
vstd::string_view BC6EncodeBlockCS();
vstd::string_view BC7Include();
vstd::string_view BC7TryMode456CS();
vstd::string_view BC7TryMode137CS();
vstd::string_view BC7TryMode02CS();
vstd::string_view BC7EncodeBlockCS();
}// namespace toolhub::directx